#' Redeconve: Deconvolution of spatial transcriptome with single cell resolution.
#'
#' Deconvolution of spatial transcriptome with single cell resolution.
#'
#'
#' @docType package
#' @name Redeconve
#' @useDynLib Redeconve, .registration=TRUE
NULL
#> NULL
